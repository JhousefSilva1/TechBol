package com.techbol.ucb.edu.bo.techbol;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TechbolApplicationTests {

	@Test
	void contextLoads() {
	}

}
